#include <termios.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <errno.h>
#include <string.h>
#include <sys/utsname.h>
#include <time.h>


#include "tslib-private.h"

static int misc_read(struct tslib_module_info *inf, struct ts_sample *samp, int nr)
{
	struct tsdev *ts = inf->dev;

	int ret;
	unsigned ts_status;
	ret = read(ts->fd, &ts_status, sizeof ts_status);
	if (ret < 0) {
		return 0;
	}
	if (ret == 0) {
		return 0;
	}

	samp->x = ((ts_status) >> 16) & 0x7FFF;
	samp->y = ts_status & 0x7FFF;
	samp->pressure = ts_status >> 31;
	gettimeofday(&samp->tv,NULL);
	nr = nr;

	return 1;
}
static int ts_fini(struct tslib_module_info *inf)
{
        free(inf);
        return 0;
}

static const struct tslib_ops misc_ops =
{
	.read	= misc_read,
        .fini   = ts_fini,
};

TSAPI struct tslib_module_info *one_wire_ts_mod_init(struct tsdev *dev, const char *params)
{
	struct tslib_module_info *m;

	m = malloc(sizeof(struct tslib_module_info));
	if (m == NULL)
		return NULL;

	m->ops = &misc_ops;
	return m;
}

#ifndef TSLIB_STATIC_FRIENDLYARM_TS_MODULE
TSLIB_MODULE_INIT(one_wire_ts_mod_init);
#endif
